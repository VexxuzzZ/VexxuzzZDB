export default function handler(req, res) { res.setHeader('Content-Type', 'text/plain'); res.status(200).json([ { number: "62857734669111", status: "active" }, { number: "62857734669112", status: "active" }, { number: "62857734669113", status: "active" } ]); }

